// =========================
// THEME TOGGLE (SAFE + PERSIST)
// =========================
document.addEventListener("DOMContentLoaded", () => {

    const body = document.body;
    const themeToggle = document.getElementById("themeToggle");

    // โหลด theme จาก localStorage
    const savedTheme = localStorage.getItem("theme");
    if (savedTheme === "light") {
        body.classList.remove("theme-dark");
        body.classList.add("theme-light");
    } else {
        body.classList.remove("theme-light");
        body.classList.add("theme-dark");
    }

    // ป้องกัน error ถ้าไม่มีปุ่ม
    if (themeToggle) {
        themeToggle.addEventListener("click", () => {

            if (body.classList.contains("theme-dark")) {
                body.classList.remove("theme-dark");
                body.classList.add("theme-light");
                localStorage.setItem("theme", "light");
            } else {
                body.classList.remove("theme-light");
                body.classList.add("theme-dark");
                localStorage.setItem("theme", "dark");
            }

        });
    }

    // =========================
    // SEARCH SAFE
    // =========================
    const searchInput = document.getElementById("searchInput");

    if (searchInput) {
        searchInput.addEventListener("keydown", (e) => {

            if (e.key === "Enter") {

                const keyword = searchInput.value.trim();
                if (!keyword) return;

                // เปลี่ยนเป็น redirect จริงเมื่อพร้อม
                window.location.href = `/search?keyword=${encodeURIComponent(keyword)}`;
            }

        });
    }

});
function openCartPopup() {
    document.getElementById("cartPopup").style.display = "flex";
}

function closeCartPopup() {
    document.getElementById("cartPopup").style.display = "none";
}

function increaseQty() {
    const input = document.getElementById("qtyInput");
    const max = parseInt(input.max);
    let value = parseInt(input.value);

    if (value < max) {
        input.value = value + 1;
    }
}

function decreaseQty() {
    const input = document.getElementById("qtyInput");
    let value = parseInt(input.value);

    if (value > 1) {
        input.value = value - 1;
    }
}
function handleAddToCart() {

    const isLoggedIn = document.body.dataset.loggedin === "true";

    if (!isLoggedIn) {
        showLoginError();
        return;
    }

    openCartPopup();
}

function showLoginError() {

    const popup = document.createElement("div");
    popup.className = "popup-overlay";
    popup.innerHTML = `
        <div class="popup error">
            <div class="icon">✕</div>
            <h3>Login Required</h3>
            <p>Please login before adding items to cart.</p>
        </div>
    `;

    document.body.appendChild(popup);

    setTimeout(() => {
        popup.remove();
    }, 1500);
}
function handleBuyNow() {

    const isLoggedIn = document.body.dataset.loggedin === "true";

    if (!isLoggedIn) {
        showLoginError();
        return;
    }

    openBuyPopup();
}

function openBuyPopup() {
    document.getElementById("buyPopup").style.display = "flex";
}

function closeBuyPopup() {
    document.getElementById("buyPopup").style.display = "none";
}

function increaseBuyQty() {
    const input = document.getElementById("buyQtyInput");
    const max = parseInt(input.max);
    let value = parseInt(input.value);

    if (value < max) {
        input.value = value + 1;
    }
}

function decreaseBuyQty() {
    const input = document.getElementById("buyQtyInput");
    let value = parseInt(input.value);

    if (value > 1) {
        input.value = value - 1;
    }
}
// ==========================
// LOGIN POPUP CONTROL
// ==========================

let loginPopupTimer = null;

function openLoginPopup() {

    const popup = document.getElementById("loginPopup");

    if (!popup) return;

    popup.style.display = "flex";

    // 🔥 เคลียร์ timer เก่าก่อน
    if (loginPopupTimer) {
        clearTimeout(loginPopupTimer);
    }

    // 🔥 ตั้งเวลาให้หายเองใน 2 วิ
    loginPopupTimer = setTimeout(() => {
        closeLoginPopup();
    }, 2000);

}

function closeLoginPopup() {

    const popup = document.getElementById("loginPopup");

    if (!popup) return;

    popup.classList.add("fade-out");

    setTimeout(() => {
        popup.style.display = "none";
        popup.classList.remove("fade-out");
    }, 300);

}

