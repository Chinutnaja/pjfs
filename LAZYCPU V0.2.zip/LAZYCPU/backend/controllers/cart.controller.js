const Product = require('../models/product.model');
const Order = require('../models/order.model');
const OrderItem = require('../models/orderItem.model');
const AppError = require('../utils/AppError');


// =====================
// ADD TO CART
// =====================
exports.addToCart = (req, res, next) => {

    // 🔐 ต้อง login ก่อน
    if (!req.session.user) {
        return next(new AppError("Please login first.", 401));
    }

    const productId = req.params.id;
    const quantity = parseInt(req.query.qty) || 1;

    // ตรวจ qty ไม่ให้ต่ำกว่า 1
    if (quantity <= 0) {
        return next(new AppError("Invalid quantity.", 400));
    }

    Product.getProductById(productId, (err, product) => {

        if (err) {
            return next(new AppError("Database error.", 500));
        }

        if (!product) {
            return next(new AppError("Product not found.", 404));
        }

        // เช็ค stock
        if (quantity > product.stock) {
            return next(new AppError("Requested quantity exceeds stock.", 400));
        }

        // สร้าง cart ถ้ายังไม่มี
        if (!req.session.cart) {
            req.session.cart = [];
        }

        const existingItem = req.session.cart.find(
            item => item.product_Id == product.product_Id
        );

        if (existingItem) {

            const newQty = existingItem.quantity + quantity;

            if (newQty > product.stock) {
                return next(new AppError("Total quantity exceeds stock.", 400));
            }

            existingItem.quantity = newQty;

        } else {

            req.session.cart.push({
                product_Id: product.product_Id,
                product_Name: product.product_Name,
                price: product.display_price || product.price,
                image_path: product.image_path,
                stock: product.stock,
                quantity: quantity
            });

        }

        // redirect กลับ cart พร้อม success popup
        res.redirect('/cart?success=added');
    });
};


// =====================
// VIEW CART
// =====================
exports.viewCart = (req, res, next) => {

    if (!req.session.user) {
        return next(new AppError("Please login to view your cart.", 401));
    }

    const cart = req.session.cart || [];

    let total = 0;
    cart.forEach(item => {
        total += item.price * item.quantity;
    });

    res.render('cart/cart', {
        cart,
        total,
        user: req.session.user,
        currentPage: null,
        success: req.query.success || null
    });

};


// =====================
// REMOVE ITEM
// =====================
exports.removeItem = (req, res, next) => {

    if (!req.session.user) {
        return next(new AppError("Please login first.", 401));
    }

    const id = req.params.id;

    req.session.cart = (req.session.cart || []).filter(
        item => item.product_Id != id
    );

    res.redirect('/cart');
};


// =====================
// CHECKOUT
// =====================
exports.checkout = (req, res, next) => {

    if (!req.session.user) {
        return next(new AppError("Please login first.", 401));
    }

    const cart = req.session.cart || [];

    if (cart.length === 0) {
        return next(new AppError("Your cart is empty.", 400));
    }

    const customerId = req.session.user.customerId;

    let totalAmount = 0;
    cart.forEach(item => {
        totalAmount += item.price * item.quantity;
    });

    Order.createOrder({
        order_Date: new Date().toISOString(),
        total_Amount: totalAmount,
        orderType: 'product',
        buildName: null,
        customerId
    }, (err, orderId) => {

        if (err) {
            return next(new AppError("Order creation failed.", 500));
        }

        cart.forEach(item => {
            OrderItem.createOrderItem({
                quantity: item.quantity,
                unitPrice: item.price,
                totalPrice: item.price * item.quantity,
                orderId,
                productId: item.product_Id
            }, () => {});
        });

        req.session.cart = [];

        res.redirect(`/payments/${orderId}`);
    });
};
