const db = require('../database/db');

// CREATE OrderItem
exports.createOrderItem = (data, callback) => {
    const sql = `
        INSERT INTO OrderItems
        (quantity, unitPrice, totalPrice, orderId, productId)
        VALUES (?, ?, ?, ?, ?)
    `;

    db.run(sql, [
        data.quantity,
        data.unitPrice,
        data.totalPrice,
        data.orderId,
        data.productId
    ], function(err) {
        callback(err, this?.lastID);
    });
};

// GET items by orderId
exports.getItemsByOrderId = (orderId, callback) => {
    db.all(`
        SELECT 
            oi.*, 
            p.product_Name,
            p.image_path
        FROM OrderItems oi
        JOIN Products p ON oi.productId = p.product_Id
        WHERE oi.orderId = ?
    `, [orderId], callback);
};

exports.getOrdersByCustomer = (customerId, callback) => {

    const sql = `
        SELECT *
        FROM Orders
        WHERE customerId = ?
        ORDER BY order_Id DESC
    `;

    db.all(sql, [customerId], callback);
};
