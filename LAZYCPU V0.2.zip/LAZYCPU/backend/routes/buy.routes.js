const express = require('express');
const router = express.Router();
const controller = require('../controllers/buy.controller');

router.post('/buy/:id', controller.buyNow);

module.exports = router;
