const express = require('express');
const router = express.Router();
const productController = require('../controllers/product.controller');
const adminController = require('../controllers/admin.controller');

// Dashboard
router.get('/admin', require('../controllers/admin.controller').dashboard);
router.get('/admin/customers', adminController.adminCustomers);

// Products (Admin Only)
router.get('/admin/products', productController.getAllProducts);
router.get('/admin/products/create', productController.showCreateForm);
router.post('/admin/products/create', productController.createProduct);
router.get('/admin/products/edit/:id', productController.showEditForm);
router.post('/admin/products/edit/:id', productController.updateProduct);
router.get('/admin/products/delete/:id', productController.deleteProduct);
router.get('/admin/customers/delete/:id', adminController.deleteCustomer);
router.get('/admin/orders', adminController.adminOrders);
router.post('/admin/orders/update', adminController.updateOrderStatus);
router.post('/admin/orders/approve', adminController.approveSlip);
router.post('/admin/orders/reject', adminController.rejectSlip);

module.exports = router;
