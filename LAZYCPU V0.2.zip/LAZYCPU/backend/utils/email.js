const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS
    }

});

exports.sendOTP = async (to, otp) => {

    await transporter.sendMail({
        from: 'LazyCPU <YOUR_EMAIL@gmail.com>',
        to,
        subject: 'Verify your account - LazyCPU',
        html: `
            <h2>LazyCPU Email Verification</h2>
            <p>Your OTP code is:</p>
            <h1>${otp}</h1>
            <p>This code will expire in 5 minutes.</p>
        `
    });
};
