const express = require('express');
const path = require('path');

const app = express(); 

require('./database/db');
require('dotenv').config();

// view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static('public'));
app.use(express.static(path.join(__dirname, 'public')));

const authRoutes = require('./routes/auth.routes');
app.use('/', authRoutes);

// routes
const productRoutes = require('./routes/product.routes');
app.use('/', productRoutes);

const orderRoutes = require('./routes/order.routes');
app.use('/', orderRoutes);

const customerRoutes = require('./routes/customer.routes');
app.use('/', customerRoutes);

const homeController = require('./controllers/home.controller');
app.get('/', homeController.showHome);

const errorHandler = require('./middleware/errorHandler');
app.use(errorHandler);



app.listen(3000, () => {
    console.log('Server running at http://localhost:3000');
});
