const bcrypt = require('bcrypt');
const crypto = require('crypto');
const emailService = require('../utils/email');
const Customer = require('../models/customer.model');
const AppError = require('../utils/AppError');


// ==========================
// REGISTER + SEND OTP
// ==========================
exports.register = async (req, res, next) => {

    const { firstname, lastname, email, phone, address, username, password } = req.body;

    if (!username || !password || !email) {
        return next(new AppError(
            "All mandatory registration fields must be completed before submission.",
            400
        ));
    }

    try {

        const hashedPassword = await bcrypt.hash(password, 10);

        const otp = Math.floor(100000 + Math.random() * 900000).toString();
        const otpExpire = Date.now() + 5 * 60 * 1000;

        Customer.createWithOTP({
            firstname,
            lastname,
            email,
            phone,
            address,
            username,
            password_hash: hashedPassword,
            role: 'customer',
            otp_code: otp,
            otp_expire: otpExpire,
            is_verified: 0
        }, async (err) => {

            if (err) {
                console.error("SQL ERROR:", err);
                return next(new AppError(
                    "The provided username or email is already registered in the system.",
                    400
                ));
            }

            try {
                await emailService.sendOTP(email, otp);
            } catch (emailErr) {
                console.error("EMAIL ERROR:", emailErr);
                return next(new AppError(
                    "The account was created, but the verification email could not be delivered. Please contact the administrator.",
                    500
                ));
            }

            res.redirect(`/verify?email=${email}&success=registered`);
        });

    } catch (error) {
        next(new AppError(
            "An unexpected system error occurred during registration. Please try again later.",
            500
        ));
    }
};


// ==========================
// VERIFY OTP
// ==========================
exports.verifyOTP = (req, res, next) => {

    const { email, otp } = req.body;

    Customer.getByEmail(email, (err, user) => {

        if (err) {
            return next(new AppError(
                "An unexpected system error occurred while retrieving account information.",
                500
            ));
        }

        if (!user) {
            return next(new AppError(
                "The specified account could not be found in the system.",
                404
            ));
        }

        if (user.is_verified === 1) {
            return next(new AppError(
                "This account has already been verified.",
                400
            ));
        }

        if (user.otp_code !== otp) {
            return next(new AppError(
                "The verification code provided is invalid.",
                400
            ));
        }

        if (Date.now() > user.otp_expire) {
            return next(new AppError(
                "The verification code has expired. Please request a new verification code.",
                400
            ));
        }

        Customer.verifyUser(email, (err2) => {

            if (err2) {
                return next(new AppError(
                    "Account verification failed due to a system issue. Please try again later.",
                    500
                ));
            }

            res.json({ message: 'Email verified successfully' });
        });
    });
};


// ==========================
// LOGIN
// ==========================
exports.login = async (req, res, next) => {

    const { identifier, password } = req.body;

    Customer.getByUsernameOrEmail(identifier, async (err, user) => {

        if (err) {
            return next(new AppError(
                "An unexpected system error occurred during authentication.",
                500
            ));
        }

        if (!user) {
            return next(new AppError(
                "Invalid login credentials. Please verify your information and try again.",
                401
            ));
        }

        if (user.is_verified === 0) {
            return next(new AppError(
                "Your account has not yet been verified. Please complete email verification before logging in.",
                403
            ));
        }

        const match = await bcrypt.compare(password, user.password_hash);

        if (!match) {
            return next(new AppError(
                "Invalid login credentials. Please verify your information and try again.",
                401
            ));
        }

        res.redirect('/?success=login');
    });
};


exports.verifySubmit = (req, res, next) => {

    const { email, otp } = req.body;

    Customer.verifyOTP(email, otp, (err, success) => {

        if (err) {
            return next(new AppError(
                "An unexpected system error occurred during verification.",
                500
            ));
        }

        if (!success) {
            return next(new AppError(
                "The verification code provided is invalid or has expired.",
                400
            ));
        }

        res.redirect('/login?success=verified');
    });
};


exports.showLogin = (req, res) => {
    res.render('auth/login', {
        success: req.query.success || null
    });
};

exports.showRegister = (req, res) => {
    res.render('auth/register', {
        success: req.query.success || null
    });
};

exports.showVerify = (req, res) => {
    res.render('auth/verify', {
        email: req.query.email,
        success: req.query.success || null
    });
};
