const Product = require('../models/product.model');
const AppError = require('../utils/AppError');

exports.showHome = (req, res, next) => {

    Product.getByRole('promotion', (err, promotions) => {

        if (err) {
            return next(new AppError(
                "Unable to retrieve promotional products due to a system error.",
                500
            ));
        }

        Product.getByRole('trending', (err2, trending) => {

            if (err2) {
                return next(new AppError(
                    "Unable to retrieve trending products due to a system error.",
                    500
                ));
            }

            Product.getByRole('bestseller', (err3, bestseller) => {

                if (err3) {
                    return next(new AppError(
                        "Unable to retrieve bestseller products due to a system error.",
                        500
                    ));
                }

                res.render('index', {
                promotions: promotions || [],
                trending: trending || [],
                bestseller: bestseller || [],
                success: req.query.success || null
});

            });
        });
    });
};

