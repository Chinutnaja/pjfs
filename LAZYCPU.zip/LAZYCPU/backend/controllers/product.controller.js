const Product = require('../models/product.model');
const fs = require('fs');
const path = require('path');
const AppError = require('../utils/AppError');


// ==========================
// LIST
// ==========================
exports.getAllProducts = (req, res, next) => {

    Product.getAllProducts((err, rows) => {

        if (err) {
            return next(new AppError(
                "Unable to retrieve product records due to a system error.",
                500
            ));
        }

        res.render('products/list', {
            products: rows,
            success: req.query.success || null
        });
    });
};



// ==========================
// DETAIL
// ==========================
exports.getProductDetail = (req, res, next) => {

    const productId = req.params.id;

    Product.getProductById(productId, (err, product) => {

        if (err) {
            return next(new AppError(
                "An error occurred while retrieving the requested product information.",
                500
            ));
        }

        if (!product) {
            return next(new AppError(
                "The requested product could not be found in the system.",
                404
            ));
        }

        Product.getRolesByProduct(productId, (err2, roles) => {

            if (!err2 && roles) {
                product.roles = roles.map(r => r.role_name);
            } else {
                product.roles = [];
            }

            if (product.original_price && product.discount_price) {
                product.discountPercent = Math.round(
                    ((product.original_price - product.discount_price)
                        / product.original_price) * 100
                );
            }

            res.render('products/detail', { product });
        });
    });
};


// ==========================
// SHOW CREATE
// ==========================
exports.showCreateForm = (req, res) => {
    res.render('products/create');
};


// ==========================
// CREATE
// ==========================
exports.createProduct = (req, res, next) => {

    const type = req.body.type;
    const roleInput = req.body.roles;

    const roles = Array.isArray(roleInput)
        ? roleInput
        : [roleInput];

    let category = req.body.category;

    if (type === 'pc_set') {
        category = null;
    }

    let price = 0;
    let originalPrice = null;
    let discountPrice = null;

    if (roles && roles.includes('promotion')) {

        originalPrice = parseFloat(req.body.original_price) || 0;
        discountPrice = parseFloat(req.body.discount_price) || 0;
        price = discountPrice;

    } else {
        price = parseFloat(req.body.price) || 0;
    }

    const imagePath = req.file
        ? '/uploads/' + req.file.filename
        : null;

    const data = {
        product_Code: req.body.product_Code,
        product_Name: req.body.product_Name,
        category,
        price,
        original_price: originalPrice,
        discount_price: discountPrice,
        type,
        stock: parseInt(req.body.stock),
        description: req.body.description,
        image_path: imagePath
    };

    Product.createProduct(data, function (err) {

        if (err) {
            console.log(err);
            return next(new AppError(
                "Product creation failed due to a system constraint or invalid input.",
                400
            ));
        }

        const productId = this.lastID;

        roles.forEach(roleName => {
            Product.addRoleToProduct(productId, roleName);
        });

        res.redirect('/products?success=created');
    });
};


// ==========================
// SHOW EDIT
// ==========================
exports.showEditForm = (req, res, next) => {

    Product.getProductById(req.params.id, (err, product) => {

        if (err) {
            return next(new AppError(
                "An error occurred while retrieving the requested product information.",
                500
            ));
        }

        if (!product) {
            return next(new AppError(
                "The requested product could not be found in the system.",
                404
            ));
        }

        res.render('products/edit', { product });
    });
};


// ==========================
// UPDATE
// ==========================
exports.updateProduct = (req, res, next) => {

    const productId = req.params.id;

    const type = req.body.type;
    const roleInput = req.body.roles;

    const roles = Array.isArray(roleInput)
        ? roleInput
        : [roleInput];

    let category = req.body.category;

    if (type === 'pc_set') {
        category = null;
    }

    let price = 0;
    let originalPrice = null;
    let discountPrice = null;

    if (roles.includes('promotion')) {

        originalPrice = parseFloat(req.body.original_price) || 0;
        discountPrice = parseFloat(req.body.discount_price) || 0;
        price = discountPrice;

    } else {
        price = parseFloat(req.body.price) || 0;
    }

    const imagePath = req.file
        ? '/uploads/' + req.file.filename
        : req.body.old_image;

    const data = {
        product_Code: req.body.product_Code,
        product_Name: req.body.product_Name,
        category,
        price,
        original_price: originalPrice,
        discount_price: discountPrice,
        type,
        stock: req.body.stock,
        description: req.body.description,
        image_path: imagePath
    };

    Product.updateProduct(productId, data, (err) => {

        if (err) {
            console.log(err);
            return next(new AppError(
                "Product update operation failed due to a system error.",
                400
            ));
        }

        Product.clearRoles(productId, () => {

            roles.forEach(roleName => {
                Product.addRoleToProduct(productId, roleName);
            });

            res.redirect('/products?success=created');
        });
    });
};


// ==========================
// DELETE
// ==========================
exports.deleteProduct = (req, res, next) => {

    Product.getProductById(req.params.id, (err, product) => {

        if (err) {
            return next(new AppError(
                "An error occurred while retrieving the requested product.",
                500
            ));
        }

        if (!product) {
            return next(new AppError(
                "The requested product could not be found in the system.",
                404
            ));
        }

        if (product.image_path) {

            const filePath = path.join(
                __dirname,
                '..',
                'public',
                product.image_path
            );

            if (fs.existsSync(filePath)) {
                fs.unlinkSync(filePath);
            }
        }

        Product.deleteProduct(req.params.id, (deleteErr) => {

            if (deleteErr) {
                return next(new AppError(
                    "Product deletion could not be completed due to a system error.",
                    500
                ));
            }

            res.redirect('/products?success=created');
        });
    });
};
