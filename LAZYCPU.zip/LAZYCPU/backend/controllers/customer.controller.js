const Customer = require('../models/customer.model');
const AppError = require('../utils/AppError');

exports.showCreateForm = (req, res) => {
    res.render('customers/create');
};

exports.create = (req, res, next) => {

    Customer.createCustomer(req.body, (err) => {

        if (err) {
            return next(new AppError(
                "Customer creation failed due to a system constraint or invalid input.",
                400
            ));
        }

        res.redirect('/customers');
    });
};

exports.list = (req, res, next) => {

    Customer.getAllCustomers((err, rows) => {

        if (err) {
            return next(new AppError(
                "Unable to retrieve customer records due to a system error.",
                500
            ));
        }

        res.render('customers/list', { customers: rows });
    });
};

exports.showEditForm = (req, res, next) => {

    Customer.getCustomerById(req.params.id, (err, row) => {

        if (err) {
            return next(new AppError(
                "An error occurred while retrieving the requested customer information.",
                500
            ));
        }

        if (!row) {
            return next(new AppError(
                "The requested customer record could not be found in the system.",
                404
            ));
        }

        res.render('customers/edit', { customer: row });
    });
};

exports.update = (req, res, next) => {

    Customer.updateCustomer(req.params.id, req.body, (err) => {

        if (err) {
            return next(new AppError(
                "Customer update operation failed due to a system error.",
                400
            ));
        }

        res.redirect('/customers');
    });
};

exports.delete = (req, res, next) => {

    Customer.deleteCustomer(req.params.id, (err) => {

        if (err) {
            return next(new AppError(
                "Customer deletion could not be completed due to a system error.",
                500
            ));
        }

        res.redirect('/customers');
    });
};
