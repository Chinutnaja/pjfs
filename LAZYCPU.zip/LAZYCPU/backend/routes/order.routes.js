const express = require('express');
const router = express.Router();
const controller = require('../controllers/order.controller');

router.post('/orders/create', controller.createOrder);
router.get('/orders', controller.listOrders);
router.get('/orders/:id', controller.getOrderById);

module.exports = router;
