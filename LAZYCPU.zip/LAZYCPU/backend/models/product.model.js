const db = require('../database/db');

exports.createProduct = (data, callback) => {

    const sql = `
        INSERT INTO Products
        (
            product_Code,
            product_Name,
            category,
            price,
            original_price,
            discount_price,
            type,
            stock,
            description,
            image_path
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    db.run(sql, [
        data.product_Code,
        data.product_Name,
        data.category,
        data.price,
        data.original_price,
        data.discount_price,
        data.type,
        data.stock,
        data.description,
        data.image_path
    ], callback);
};


exports.getAllProducts = (callback) => {

    const sql = `
        SELECT 
            p.*,
            GROUP_CONCAT(r.role_name) as roles,
            CASE 
                WHEN p.discount_price IS NOT NULL 
                THEN p.discount_price
                ELSE p.price
            END as display_price
        FROM Products p
        LEFT JOIN ProductRoles pr ON p.product_Id = pr.productId
        LEFT JOIN Roles r ON pr.roleId = r.role_Id
        GROUP BY p.product_Id
    `;

    db.all(sql, [], callback);
};


exports.getProductById = (id, callback) => {

    const sql = `
        SELECT 
            *,
            CASE 
                WHEN discount_price IS NOT NULL 
                THEN discount_price
                ELSE price
            END as display_price
        FROM Products
        WHERE product_Id = ?
    `;

    db.get(sql, [id], callback);
};


exports.updateProduct = (id, data, callback) => {

    const sql = `
        UPDATE Products SET
            product_Code = ?,
            product_Name = ?,
            category = ?,
            price = ?,
            original_price = ?,
            discount_price = ?,
            type = ?,
            stock = ?,
            description = ?,
            image_path = ?
        WHERE product_Id = ?
    `;

    db.run(sql, [
        data.product_Code,
        data.product_Name,
        data.category,
        data.price,
        data.original_price,
        data.discount_price,
        data.type,
        data.stock,
        data.description,
        data.image_path,
        id
    ], callback);
};


exports.deleteProduct = (id, callback) => {
    db.run(`DELETE FROM Products WHERE product_Id = ?`, [id], callback);
};

exports.getByType = (type, callback) => {
    db.all(`SELECT * FROM Products WHERE type = ?`, [type], callback);
};

exports.getByRole = (roleName, callback) => {

    const sql = `
        SELECT 
            p.*,
            GROUP_CONCAT(r.role_name) as roles,
            CASE 
                WHEN p.discount_price IS NOT NULL 
                THEN p.discount_price
                ELSE p.price
            END as display_price
        FROM Products p
        JOIN ProductRoles pr ON p.product_Id = pr.productId
        JOIN Roles r ON r.role_Id = pr.roleId
        WHERE r.role_name = ?
        GROUP BY p.product_Id
    `;

    db.all(sql, [roleName], callback);
};
;


exports.addRoleToProduct = (productId, roleName) => {

    const sql = `
        INSERT INTO ProductRoles (productId, roleId)
        SELECT ?, role_Id FROM Roles WHERE role_name = ?
    `;

    db.run(sql, [productId, roleName]);
};
exports.getRolesByProduct = (productId, callback) => {

    const sql = `
        SELECT r.role_name
        FROM Roles r
        JOIN ProductRoles pr ON r.role_Id = pr.roleId
        WHERE pr.productId = ?
    `;

    db.all(sql, [productId], callback);
};

exports.clearRoles = (productId, callback) => {
    db.run(
        `DELETE FROM ProductRoles WHERE productId = ?`,
        [productId],
        callback
    );
};
