// =========================
// THEME TOGGLE
// =========================
const themeToggle = document.getElementById("themeToggle");

themeToggle.addEventListener("click", () => {
    const body = document.body;

    if (body.classList.contains("theme-dark")) {
        body.classList.remove("theme-dark");
        body.classList.add("theme-light");
    } else {
        body.classList.remove("theme-light");
        body.classList.add("theme-dark");
    }
});

// =========================
// SEARCH DEMO
// =========================
const searchInput = document.getElementById("searchInput");

searchInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
        const keyword = searchInput.value.trim();

        if (!keyword) return;

        alert("Search for: " + keyword);

        // later:
        // window.location.href = `/shop?search=${keyword}`;
    }
});
