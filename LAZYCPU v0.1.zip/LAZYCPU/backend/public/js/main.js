// =========================
// THEME TOGGLE (SAFE + PERSIST)
// =========================
document.addEventListener("DOMContentLoaded", () => {

    const body = document.body;
    const themeToggle = document.getElementById("themeToggle");

    // โหลด theme จาก localStorage
    const savedTheme = localStorage.getItem("theme");
    if (savedTheme === "light") {
        body.classList.remove("theme-dark");
        body.classList.add("theme-light");
    } else {
        body.classList.remove("theme-light");
        body.classList.add("theme-dark");
    }

    // ป้องกัน error ถ้าไม่มีปุ่ม
    if (themeToggle) {
        themeToggle.addEventListener("click", () => {

            if (body.classList.contains("theme-dark")) {
                body.classList.remove("theme-dark");
                body.classList.add("theme-light");
                localStorage.setItem("theme", "light");
            } else {
                body.classList.remove("theme-light");
                body.classList.add("theme-dark");
                localStorage.setItem("theme", "dark");
            }

        });
    }

    // =========================
    // SEARCH SAFE
    // =========================
    const searchInput = document.getElementById("searchInput");

    if (searchInput) {
        searchInput.addEventListener("keydown", (e) => {

            if (e.key === "Enter") {

                const keyword = searchInput.value.trim();
                if (!keyword) return;

                // เปลี่ยนเป็น redirect จริงเมื่อพร้อม
                window.location.href = `/search?keyword=${encodeURIComponent(keyword)}`;
            }

        });
    }

});
