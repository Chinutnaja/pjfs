const express = require('express');
const router = express.Router();
const controller = require('../controllers/buy.controller');

router.post('/buy-now', controller.buyNow);

module.exports = router;
