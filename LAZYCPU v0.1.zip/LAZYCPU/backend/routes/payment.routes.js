const express = require('express');
const router = express.Router();
const controller = require('../controllers/payment.controller');
const multer = require('multer');
const path = require('path');

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'public/slips/');
    },
    filename: (req, file, cb) => {
        cb(null, 'SLIP-' + Date.now() + path.extname(file.originalname));
    }
});

const upload = multer({ storage });

router.get('/payments/:orderId', controller.showPaymentPage);
router.post('/payments/pay-slip', upload.single('slip'), controller.payWithSlip);

module.exports = router;
