const express = require('express');
const router = express.Router();
const controller = require('../controllers/customer.controller');

router.get('/customers', controller.list);
router.get('/customers/create', controller.showCreateForm);
router.post('/customers/create', controller.create);

router.get('/customers/edit/:id', controller.showEditForm);
router.post('/customers/edit/:id', controller.update);

router.get('/customers/delete/:id', controller.delete);

module.exports = router;
