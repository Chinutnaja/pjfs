const Product = require('../models/product.model');
const Order = require('../models/order.model');
const OrderItem = require('../models/orderItem.model');
const AppError = require('../utils/AppError');

exports.buyNow = (req, res, next) => {

    if (!req.session.user) {
        return next(new AppError(
            "Please login before purchasing.",
            401
        ));
    }

    const productId = req.body.productId;
    const customerId = req.session.user.customer_Id;

    Product.getProductById(productId, (err, product) => {

        if (err || !product) {
            return next(new AppError(
                "Product not found.",
                404
            ));
        }

        const totalAmount = product.price;

        Order.createOrder({
            order_Date: new Date().toISOString(),
            total_Amount: totalAmount,
            orderType: 'product',
            buildName: null,
            customerId
        }, (err2, orderId) => {

            if (err2) {
                return next(new AppError(
                    "Order creation failed.",
                    500
                ));
            }

            OrderItem.createOrderItem({
                quantity: 1,
                unitPrice: product.price,
                totalPrice: product.price,
                orderId: orderId,
                productId: productId
            }, () => {

                res.redirect(`/payments/${orderId}`);

            });

        });

    });
};
