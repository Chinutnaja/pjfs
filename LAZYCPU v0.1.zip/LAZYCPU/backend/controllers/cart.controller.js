const Product = require('../models/product.model');
const AppError = require('../utils/AppError');


// =====================
// ADD TO CART
// =====================
exports.addToCart = (req, res, next) => {

    if (!req.session.user) {
        return next(new AppError(
            "Please login before adding items to cart.",
            401
        ));
    }

    const productId = req.body.productId;

    Product.getProductById(productId, (err, product) => {

        if (err || !product) {
            return next(new AppError(
                "Product not found.",
                404
            ));
        }

        if (!req.session.cart) {
            req.session.cart = [];
        }

        const existing = req.session.cart.find(p => p.productId == productId);

        if (existing) {
            existing.quantity += 1;
        } else {
            req.session.cart.push({
                productId: product.product_Id,
                name: product.product_Name,
                price: product.price,
                quantity: 1,
                image: product.image_path
            });
        }

        return next(new AppError(
            "Product added to cart successfully.",
            200
        ));
    });
};



// =====================
// VIEW CART
// =====================
exports.viewCart = (req, res) => {

    const cart = req.session.cart || [];

    let total = 0;
    cart.forEach(item => {
        total += item.price * item.quantity;
    });

    res.render('cart/cart', {
        cart,
        total,
        user: req.session.user || null
    });
};



// =====================
// REMOVE ITEM
// =====================
exports.removeItem = (req, res) => {

    const id = req.params.id;

    if (!req.session.cart) return res.redirect('/cart');

    req.session.cart = req.session.cart.filter(item => item.productId != id);

    res.redirect('/cart');
};
