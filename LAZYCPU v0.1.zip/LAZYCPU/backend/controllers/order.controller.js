const Order = require('../models/order.model');
const OrderItem = require('../models/orderItem.model');
const Product = require('../models/product.model');
const AppError = require('../utils/AppError');


// ==========================
// CREATE ORDER
// ==========================
exports.createOrder = async (req, res, next) => {

    const { customerId, items } = req.body;

    if (!customerId || !items || !Array.isArray(items)) {
        return next(new AppError(
            "The order request format is invalid. Please verify the submitted data.",
            400
        ));
    }

    let totalAmount = 0;

    try {

        for (let item of items) {

            const product = await new Promise((resolve, reject) => {
                Product.getProductById(item.productId, (err, row) => {
                    if (err) reject(err);
                    else resolve(row);
                });
            });

            if (!product) {
                return next(new AppError(
                    "One or more requested products could not be found in the system.",
                    404
                ));
            }

            if (product.stock < item.quantity) {
                return next(new AppError(
                    "The requested quantity exceeds the available stock for one or more products.",
                    400
                ));
            }

            item.unitPrice = product.price;
            item.totalPrice = product.price * item.quantity;
            item.newStock = product.stock - item.quantity;

            totalAmount += item.totalPrice;
        }

        Order.createOrder({
            order_Date: new Date().toISOString(),
            total_Amount: totalAmount,
            orderType: 'product',
            buildName: null,
            customerId
        }, (err, orderId) => {

            if (err) {
                return next(new AppError(
                    "Order creation failed due to a system error.",
                    500
                ));
            }

            items.forEach(item => {

                OrderItem.createOrderItem({
                    quantity: item.quantity,
                    unitPrice: item.unitPrice,
                    totalPrice: item.totalPrice,
                    orderId: orderId,
                    productId: item.productId
                }, () => {});
            });

            res.json({
                message: 'Order created successfully',
                orderId: orderId,
                totalAmount: totalAmount
            });
        });

    } catch (error) {
        console.error(error);
        return next(new AppError(
            "An unexpected system error occurred while processing the order.",
            500
        ));
    }
};


// ==========================
// GET ALL ORDERS
// ==========================
exports.listOrders = (req, res, next) => {

    Order.getAllOrders((err, rows) => {

        if (err) {
            return next(new AppError(
                "Unable to retrieve order records due to a system error.",
                500
            ));
        }

        res.json(rows);
    });
};


// ==========================
// GET ORDER BY ID
// ==========================
exports.getOrderById = (req, res, next) => {

    const id = req.params.id;

    Order.getOrderById(id, (err, order) => {

        if (err) {
            return next(new AppError(
                "An error occurred while retrieving the requested order.",
                500
            ));
        }

        if (!order) {
            return next(new AppError(
                "The requested order record could not be found in the system.",
                404
            ));
        }

        OrderItem.getItemsByOrderId(id, (err, items) => {

            if (err) {
                return next(new AppError(
                    "An error occurred while retrieving order item details.",
                    500
                ));
            }

            res.json({
                order: order,
                items: items
            });
        });
    });
};
