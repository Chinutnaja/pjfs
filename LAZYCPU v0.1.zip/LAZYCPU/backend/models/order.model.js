const db = require('../database/db');

// CREATE Order
exports.createOrder = (data, callback) => {
    const sql = `
        INSERT INTO Orders
        (order_Date, total_Amount, paymentStatus, shippingStatus, orderType, buildName, customerId)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    `;

    db.run(sql, [
        data.order_Date,
        data.total_Amount,
        data.paymentStatus || 'pending',
        data.shippingStatus || 'preparing',
        data.orderType,
        data.buildName || null,
        data.customerId
    ], function(err) {
        callback(err, this?.lastID);
    });
};

// GET ALL Orders
exports.getAllOrders = (callback) => {
    db.all(`
        SELECT o.*, c.firstname || ' ' || c.lastname AS customerName
        FROM Orders o
        JOIN Customers c ON o.customerId = c.customer_Id
    `, [], callback);
};

// GET ONE Order
exports.getOrderById = (id, callback) => {
    db.get(`
        SELECT * FROM Orders WHERE order_Id = ?
    `, [id], callback);
};
exports.updatePaymentStatus = (orderId, status, callback) => {
    db.run(
        `UPDATE Orders SET paymentStatus = ? WHERE order_Id = ?`,
        [status, orderId],
        callback
    );
};
