const db = require('../database/db');

exports.createPayment = (data, callback) => {

    const sql = `
        INSERT INTO Payments
        (orderId, paymentDate, amount, paymentMethod, transactionRef, paymentStatus)
        VALUES (?, ?, ?, ?, ?, ?)
    `;

    db.run(sql, [
        data.orderId,
        data.paymentDate,
        data.amount,
        data.paymentMethod,
        data.transactionRef,
        data.paymentStatus
    ], function (err) {
        callback(err, this?.lastID);
    });
};

exports.updatePaymentStatus = (paymentId, status, callback) => {

    db.run(
        `UPDATE Payments SET paymentStatus = ? WHERE payment_id = ?`,
        [status, paymentId],
        callback
    );
};
