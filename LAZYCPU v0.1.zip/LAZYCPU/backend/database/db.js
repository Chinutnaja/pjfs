const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const dbPath = path.join(__dirname, 'lazycpu.sqlite');


const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error('Database connection error:', err);
    } else {
        console.log('Connected to SQLite database');
    }
});

db.serialize(() => {

    // ==========================
    // Customers 
    // ==========================
    db.run(`
        CREATE TABLE IF NOT EXISTS Customers (
            customer_Id INTEGER PRIMARY KEY AUTOINCREMENT,
            firstname TEXT NOT NULL,
            lastname TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            phone TEXT,
            address TEXT NOT NULL,
            username TEXT UNIQUE,
            password_hash TEXT,
            role TEXT DEFAULT 'customer',
            otp_code TEXT,
            otp_expire INTEGER,
            is_verified INTEGER DEFAULT 0
        )
    `);

    // ==========================
    // Products
    // ==========================
    db.run(`
    CREATE TABLE IF NOT EXISTS Products (
        product_Id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_Code TEXT NOT NULL UNIQUE,
        product_Name TEXT NOT NULL,
        category TEXT,
        price REAL NOT NULL,
        original_price REAL,
        discount_price REAL,
        role TEXT DEFAULT 'normal',
        type TEXT DEFAULT 'item',
        stock INTEGER NOT NULL DEFAULT 0,
        description TEXT,
        image_path TEXT
)
`);


    // ==========================
    // Orders
    // ==========================
    db.run(`
        CREATE TABLE IF NOT EXISTS Orders (
            order_Id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_Date TEXT NOT NULL,
            total_Amount REAL NOT NULL,
            paymentStatus TEXT DEFAULT 'pending',
            shippingStatus TEXT DEFAULT 'preparing',
            orderType TEXT NOT NULL,
            buildName TEXT,
            customerId INTEGER,
            FOREIGN KEY (customerId) REFERENCES Customers(customer_Id)
        )
    `);

    // ==========================
    // OrderItems
    // ==========================
    db.run(`
        CREATE TABLE IF NOT EXISTS OrderItems (
            orderItem_id INTEGER PRIMARY KEY AUTOINCREMENT,
            quantity INTEGER NOT NULL,
            unitPrice REAL NOT NULL,
            totalPrice REAL NOT NULL,
            orderId INTEGER,
            productId INTEGER,
            FOREIGN KEY (orderId) REFERENCES Orders(order_Id),
            FOREIGN KEY (productId) REFERENCES Products(product_Id)
        )
    `);
    // ==========================
    // Payments
    // ==========================
    db.run(`
        CREATE TABLE IF NOT EXISTS Payments (
            payment_id INTEGER PRIMARY KEY AUTOINCREMENT,
            orderId INTEGER NOT NULL,
            paymentDate TEXT NOT NULL,
            amount REAL NOT NULL,
            paymentMethod TEXT NOT NULL,
            transactionRef TEXT,
            paymentStatus TEXT DEFAULT 'pending',
            FOREIGN KEY (orderId) REFERENCES Orders(order_Id)
        )
    `);

    db.run(`
    CREATE TABLE IF NOT EXISTS Roles (
        role_Id INTEGER PRIMARY KEY AUTOINCREMENT,
        role_name TEXT UNIQUE
)
    `);

    db.run(`
        CREATE TABLE IF NOT EXISTS ProductRoles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            productId INTEGER,
            roleId INTEGER,
            FOREIGN KEY (productId) REFERENCES Products(product_Id),
            FOREIGN KEY (roleId) REFERENCES Roles(role_Id)
    )
    `);
    const roles = ['normal','promotion','trending','bestseller'];

roles.forEach(r => {
    db.run(`INSERT OR IGNORE INTO Roles (role_name) VALUES (?)`, [r]);
});


});

module.exports = db;
