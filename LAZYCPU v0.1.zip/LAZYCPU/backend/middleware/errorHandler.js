module.exports = (err, req, res, next) => {

    console.error("ERROR LOG:", err);

    const statusCode = err.statusCode || 500;
    const message = err.isOperational
        ? err.message
        : "An unexpected system error has occurred. Please contact the administrator.";

    res.status(statusCode).render("error", {
        statusCode,
        message
    });
};
