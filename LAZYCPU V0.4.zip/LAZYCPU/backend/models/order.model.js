const db = require('../database/db');

// CREATE Order
exports.createOrder = (data, callback) => {
    const sql = `
        INSERT INTO Orders
        (order_Date, total_Amount, paymentStatus, shippingStatus, orderType, buildName, customerId)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    `;

    db.run(sql, [
        data.order_Date,
        data.total_Amount,
        data.paymentStatus || 'pending',
        data.shippingStatus || 'preparing',
        data.orderType,
        data.buildName || null,
        data.customerId
    ], function(err) {
        callback(err, this?.lastID);
    });
};

// GET ALL Orders
exports.getAllOrders = (callback) => {
    db.all(`
        SELECT o.*, c.firstname || ' ' || c.lastname AS customerName
        FROM Orders o
        JOIN Customers c ON o.customerId = c.customerId
    `, [], callback);
};

// GET ONE Order
exports.getOrderById = (id, callback) => {
    db.get(`
        SELECT * FROM Orders WHERE order_Id = ?
    `, [id], callback);
};
exports.updatePaymentStatus = (orderId, status, callback) => {
    db.run(
        `UPDATE Orders SET paymentStatus = ? WHERE order_Id = ?`,
        [status, orderId],
        callback
    );
};


exports.getOrdersByCustomer = (customerId, callback) => {

    const sql = `
        SELECT *
        FROM Orders
        WHERE customerId = ?
        ORDER BY order_Id DESC
    `;

    db.all(sql, [customerId], callback);

};
exports.getAllOrdersWithCustomer = (callback) => {

    const sql = `
        SELECT 
            o.order_Id,
            o.order_Date,
            o.total_Amount,
            o.paymentStatus,
            o.shippingStatus,
            o.customerId,

            c.firstname || ' ' || c.lastname AS customerName,
            c.email,

            (
                SELECT transactionRef 
                FROM Payments 
                WHERE orderId = o.order_Id 
                ORDER BY payment_id DESC 
                LIMIT 1
            ) AS transactionRef

        FROM Orders o
        LEFT JOIN Customers c 
            ON o.customerId = c.customerId
        ORDER BY o.order_Id DESC
    `;

    db.all(sql, [], callback);
};



exports.updateOrderStatus = (orderId, paymentStatus, shippingStatus, callback) => {

    const sql = `
        UPDATE Orders
        SET paymentStatus = ?, shippingStatus = ?
        WHERE order_Id = ?
    `;

    db.run(sql, [paymentStatus, shippingStatus, orderId], callback);
};
exports.deleteOrderById = (orderId, callback) => {

    db.serialize(() => {

        db.run("BEGIN TRANSACTION");

        db.run(
            `DELETE FROM OrderItems WHERE orderId = ?`,
            [orderId],
            function(err1) {

                if (err1) {
                    db.run("ROLLBACK");
                    return callback(err1);
                }

                db.run(
                    `DELETE FROM Payments WHERE orderId = ?`,
                    [orderId],
                    function(err2) {

                        if (err2) {
                            db.run("ROLLBACK");
                            return callback(err2);
                        }

                        db.run(
                            `DELETE FROM Orders WHERE order_Id = ?`,
                            [orderId],
                            function(err3) {

                                if (err3) {
                                    db.run("ROLLBACK");
                                    return callback(err3);
                                }

                                db.run("COMMIT");
                                callback(null);
                            }
                        );

                    }
                );

            }
        );

    });

};