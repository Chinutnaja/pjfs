const db = require('../database/db');

// ==========================
// CREATE (REGISTER)
// ==========================
exports.createCustomer = (data, callback) => {
    const sql = `
        INSERT INTO Customers
        (firstname, lastname, email, phone, address, username, password_hash, role)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `;

    db.run(sql, [
        data.firstname,
        data.lastname,
        data.email,
        data.phone,
        data.address,
        data.username,
        data.password_hash,
        data.role || 'customer'
    ], function(err) {
        callback(err, this?.lastID);
    });
};


// ==========================
// GET BY USERNAME (LOGIN)
// ==========================
exports.getByUsername = (username, callback) => {
    db.get(
        `SELECT * FROM Customers WHERE username = ?`,
        [username],
        callback
    );
};


// ==========================
// CRUD เดิม
// ==========================

exports.getAllCustomers = (callback) => {
    db.all(`SELECT * FROM Customers`, [], callback);
};


exports.updateCustomer = (id, data, callback) => {
    const sql = `
        UPDATE Customers SET
        firstname = ?,
        lastname = ?,
        email = ?,
        phone = ?,
        address = ?
        WHERE customerId = ?
    `;

    db.run(sql, [
        data.firstname,
        data.lastname,
        data.email,
        data.phone,
        data.address,
        id
    ], callback);
};


exports.getCustomerById = (id, callback) => {
    db.get(
        `SELECT * FROM Customers WHERE customerId = ?`,
        [id],
        callback
    );
};

exports.deleteCustomer = (id, callback) => {
    db.run(
        `DELETE FROM Customers WHERE customerId = ?`,
        [id],
        callback
    );
};

exports.createWithOTP = (data, callback) => {

    const sql = `
        INSERT INTO Customers
        (firstname, lastname, email, phone, address, username,
         password_hash, role,
         otp_code, otp_expire, is_verified)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    db.run(sql, [
        data.firstname,
        data.lastname,
        data.email,
        data.phone,
        data.address,
        data.username,
        data.password_hash,
        data.role || 'customer',
        data.otp_code,
        data.otp_expire,
        data.is_verified
    ], function(err) {
        callback(err, this?.lastID);
    });
};

exports.verifyOTP = (email, otp, callback) => {

    const sql = `
        SELECT * FROM Customers
        WHERE email = ?
        AND otp_code = ?
        AND otp_expire > ?
    `;

    db.get(sql, [email, otp, Date.now()], (err, row) => {

        if (!row) return callback(null, false);

        db.run(`
            UPDATE Customers
            SET is_verified = 1,
                otp_code = NULL,
                otp_expire = NULL
            WHERE email = ?
        `, [email], () => {
            callback(null, true);
        });
    });
};
exports.getByUsernameOrEmail = (identifier, callback) => {
    db.get(
        `SELECT * FROM Customers WHERE username = ? OR email = ?`,
        [identifier, identifier],
        callback
    );
};
exports.updatePassword = (id, hash, callback) => {
    db.run(
        `UPDATE Customers SET password_hash = ? WHERE customerId = ?`,
        [hash, id],
        callback
    );
};
exports.getByEmail = (email, callback) => {
    db.get(
        `SELECT * FROM Customers WHERE email = ?`,
        [email],
        callback
    );
};