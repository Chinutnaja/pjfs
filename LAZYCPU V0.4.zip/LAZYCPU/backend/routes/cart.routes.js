const express = require('express');
const router = express.Router();
const controller = require('../controllers/cart.controller');

// ADD TO CART (GET WITH ID)
router.get('/cart/add/:id', controller.addToCart);

// VIEW CART
router.get('/cart', controller.viewCart);

// REMOVE ITEM
router.get('/cart/remove/:id', controller.removeItem);

// CHECKOUT
router.post('/cart/checkout', controller.checkout);

module.exports = router;
