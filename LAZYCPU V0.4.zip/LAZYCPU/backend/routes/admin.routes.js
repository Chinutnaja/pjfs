const express = require('express');
const router = express.Router();

const productController = require('../controllers/product.controller');
const adminController = require('../controllers/admin.controller');

// ================= DASHBOARD =================
router.get('/', adminController.dashboard);

// ================= CUSTOMERS =================
router.get('/customers', adminController.adminCustomers);
router.get('/customers/delete/:id', adminController.deleteCustomer);

// ================= PRODUCTS =================
router.get('/products', productController.getAllProducts);
router.get('/products/create', productController.showCreateForm);
router.post('/products/create', productController.createProduct);
router.get('/products/edit/:id', productController.showEditForm);
router.post('/products/edit/:id', productController.updateProduct);
router.get('/products/delete/:id', productController.deleteProduct);

// ================= ORDERS =================
router.get('/orders', adminController.adminOrders);
router.post('/orders/update', adminController.updateOrderStatus);
router.post('/orders/approve', adminController.approveSlip);
router.post('/orders/reject', adminController.rejectSlip);
router.get('/orders/delete/:id', adminController.deleteOrder);

module.exports = router;
