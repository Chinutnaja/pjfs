const express = require('express');
const path = require('path');

const app = express();

require('./database/db');
require('dotenv').config();

// view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static('public'));
app.use(express.static(path.join(__dirname, 'public')));

const session = require('express-session');
app.use(session({
    secret: 'lazycpu_secret_key',
    resave: false,
    saveUninitialized: false
}));
app.use((req, res, next) => {
    res.locals.user = req.session.user || null;
    res.locals.currentPage = null;
    res.locals.theme = req.session.theme || 'theme-dark';
    res.locals.success = req.query.success || null;
    next();
});


// routes
const authRoutes = require('./routes/auth.routes');
app.use('/', authRoutes);

const productRoutes = require('./routes/product.routes');
app.use('/', productRoutes);

const orderRoutes = require('./routes/order.routes');
app.use('/', orderRoutes);

const customerRoutes = require('./routes/customer.routes');
app.use('/', customerRoutes);

const paymentRoutes = require('./routes/payment.routes');
app.use('/', paymentRoutes);

const cartRoutes = require('./routes/cart.routes');
app.use('/', cartRoutes);

const buyRoutes = require('./routes/buy.routes');
app.use('/', buyRoutes);

const homeController = require('./controllers/home.controller');
app.get('/', homeController.showHome);

const adminRoutes = require('./routes/admin.routes');
app.use('/admin', adminRoutes);



const errorHandler = require('./middleware/errorHandler');
app.use(errorHandler);

app.listen(3000, () => {
    console.log('Server running at http://localhost:3000');
});
