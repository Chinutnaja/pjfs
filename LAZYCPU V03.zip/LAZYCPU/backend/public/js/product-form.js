const typeSelect = document.getElementById("typeSelect");
const categoryWrapper = document.getElementById("categoryWrapper");
const normalPrice = document.getElementById("normalPrice");
const promotionPrice = document.getElementById("promotionPrice");

function toggleCategory() {
    if (!typeSelect) return;

    categoryWrapper.style.display =
        typeSelect.value === "pc_set" ? "none" : "block";
}

function togglePrice() {

    const promotionCheckbox =
        document.querySelector('input[value="promotion"]');

    if (!promotionCheckbox) return;

    const promotionChecked = promotionCheckbox.checked;

    normalPrice.style.display =
        promotionChecked ? "none" : "grid";

    promotionPrice.style.display =
        promotionChecked ? "grid" : "none";
}

if (typeSelect) {
    typeSelect.addEventListener("change", toggleCategory);
}

document.querySelectorAll('input[name="roles"]')
    .forEach(cb => cb.addEventListener("change", togglePrice));

toggleCategory();
togglePrice();
