const requiredParts = [
    "case",
    "mainboard",
    "cpu",
    "ram",
    "psu",
    "ssd"
];

let selectedParts = {};
let totalPrice = 0;

function updateSummary() {

    const container = document.getElementById("selectedParts");
    container.innerHTML = "";
    totalPrice = 0;

    Object.values(selectedParts).forEach(p => {
        totalPrice += Number(p.price);

        const div = document.createElement("div");
        div.innerHTML = `${p.name} - ${p.price} ฿`;
        container.appendChild(div);
    });

    document.getElementById("buildTotal").innerText = totalPrice;

    validateBuild();
}

function validateBuild() {
    const isValid = requiredParts.every(cat => selectedParts[cat]);
    document.getElementById("checkoutBuild").disabled = !isValid;
}

document.getElementById("checkoutBuild").addEventListener("click", () => {

    fetch("/build/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(selectedParts)
    })
    .then(res => res.json())
    .then(data => {
        window.location.href = "/payment/" + data.orderId;
    });

});
document.querySelectorAll(".build-tabs button").forEach(btn => {

    btn.addEventListener("click", function() {

        const category = this.dataset.tab;

        fetch("/build/category/" + category)
        .then(res => res.json())
        .then(products => {

            const container = document.getElementById("buildProducts");
            container.innerHTML = "";

            products.forEach(p => {

                const card = document.createElement("div");
                card.className = "build-card";

                const isOut = p.stock <= 0;

                card.innerHTML = `
                    <img src="${p.image_path || '/images/no-image.png'}">
                    <div class="build-card-content">
                        <h4>${p.product_Name}</h4>
                        <div class="price">${p.display_price} ฿</div>
                        <div class="stock-info">
                            ${isOut ? 
                                `<span class="stock-out">Out of Stock</span>` :
                                `<span class="stock-in">In Stock: ${p.stock}</span>`
                            }
                        </div>
                        <button class="add-btn" ${isOut ? "disabled" : ""}>
                            ${isOut ? "Out of Stock" : "Add"}
                        </button>
                    </div>
                `;

                if (!isOut) {
                    card.querySelector(".add-btn").addEventListener("click", (e) => {

                        e.stopPropagation();

                        selectedParts[category] = {
                            product_Id: p.product_Id,
                            name: p.product_Name,
                            price: p.display_price,
                            image: p.image_path || '/images/no-image.png'
                        };

                        updateSummary();
                        updatePreview(category);
                    });
                }

                container.appendChild(card);
            });

        });

    });

});
function updatePreview(category) {

    const preview = document.getElementById("preview-" + category);

    if (!preview) return;

    preview.innerHTML = "";

    if (selectedParts[category]) {

        const img = document.createElement("img");
        img.src = selectedParts[category].image;
        img.className = "preview-thumb";

        preview.appendChild(img);
    }
}
