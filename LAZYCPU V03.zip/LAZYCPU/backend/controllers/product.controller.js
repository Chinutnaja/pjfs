const Product = require('../models/product.model');
const fs = require('fs');
const path = require('path');
const AppError = require('../utils/AppError');

/*
|--------------------------------------------------------------------------
| HELPER
|--------------------------------------------------------------------------
*/

function isAdminRoute(req) {
    return req.originalUrl.startsWith('/admin');
}

/*
|--------------------------------------------------------------------------
| LIST (Admin Only)
|--------------------------------------------------------------------------
*/

exports.getAllProducts = (req, res, next) => {

    Product.getAllProducts((err, rows) => {

        if (err) {
            return next(new AppError(
                "Unable to retrieve product records due to a system error.",
                500
            ));
        }

        res.render('products/list', {
            products: rows,
            success: req.query.success || null,
            theme: req.session.theme || 'theme-dark',
            isAdmin: true
        });

    });
};



/*
|--------------------------------------------------------------------------
| DETAIL
|--------------------------------------------------------------------------
*/

exports.getProductDetail = (req, res, next) => {

    const productId = req.params.id;

    Product.getProductById(productId, (err, product) => {

        if (err) {
            return next(new AppError(
                "An error occurred while retrieving the requested product information.",
                500
            ));
        }

        if (!product) {
            return next(new AppError(
                "The requested product could not be found in the system.",
                404
            ));
        }

        Product.getRolesByProduct(productId, (err2, roles) => {

            product.roles = (!err2 && roles)
                ? roles.map(r => r.role_name)
                : [];

            if (product.original_price && product.discount_price) {
                product.discountPercent = Math.round(
                    ((product.original_price - product.discount_price)
                        / product.original_price) * 100
                );
            }

            res.render('products/detail', {
                product,
                user: req.session.user || null,
                theme: req.session.theme || 'theme-dark'
            });

        });

    });
};


/*
|--------------------------------------------------------------------------
| SHOW CREATE (Admin Only)
|--------------------------------------------------------------------------
*/

exports.showCreateForm = (req, res) => {

    res.render("products/create", {
        theme: req.session.theme || 'theme-dark',
        isAdmin: true
    });

};


/*
|--------------------------------------------------------------------------
| CREATE (Admin Only)
|--------------------------------------------------------------------------
*/

exports.createProduct = (req, res, next) => {

    const type = req.body.type;
    const roleInput = req.body.roles;

    const roles = Array.isArray(roleInput)
        ? roleInput
        : roleInput ? [roleInput] : [];

    let category = (type === 'pc_set')
        ? null
        : req.body.category;

    let price = 0;
    let originalPrice = null;
    let discountPrice = null;

    if (roles.includes('promotion')) {

        originalPrice = parseFloat(req.body.original_price) || 0;
        discountPrice = parseFloat(req.body.discount_price) || 0;
        price = discountPrice;

    } else {
        price = parseFloat(req.body.price) || 0;
    }

    const imagePath = req.file
        ? '/uploads/' + req.file.filename
        : null;

    const data = {
        product_Code: req.body.product_Code,
        product_Name: req.body.product_Name,
        category,
        price,
        original_price: originalPrice,
        discount_price: discountPrice,
        type,
        stock: parseInt(req.body.stock),
        description: req.body.description,
        image_path: imagePath
    };

    Product.createProduct(data, function (err) {

        if (err) {
            return next(new AppError(
                "Product creation failed due to a system constraint or invalid input.",
                400
            ));
        }

        const productId = this.lastID;

        roles.forEach(roleName => {
            Product.addRoleToProduct(productId, roleName);
        });

        // 🔥 Redirect only admin
        res.redirect('/admin/products?success=created');

    });

};

/*
|--------------------------------------------------------------------------
| SHOW EDIT (Admin Only)
|--------------------------------------------------------------------------
*/

exports.showEditForm = (req, res, next) => {

    Product.getProductById(req.params.id, (err, product) => {

        if (err) {
            return next(new AppError(
                "An error occurred while retrieving the requested product information.",
                500
            ));
        }

        if (!product) {
            return next(new AppError(
                "The requested product could not be found in the system.",
                404
            ));
        }

        res.render("products/edit", {
            product,
            theme: req.session.theme || 'theme-dark',
            isAdmin: true
        });

    });

};


/*
|--------------------------------------------------------------------------
| UPDATE (Admin Only)
|--------------------------------------------------------------------------
*/

exports.updateProduct = (req, res, next) => {
    if (!req.body) {
        return next(new AppError("Form data not received.", 400));
    }

    const productId = req.params.id;
    const type = req.body?.type || 'item';
    const roleInput = req.body.roles;

    const roles = Array.isArray(roleInput)
        ? roleInput
        : roleInput ? [roleInput] : [];

    let category = (type === 'pc_set')
        ? null
        : req.body.category;

    let price = 0;
    let originalPrice = null;
    let discountPrice = null;

    if (roles.includes('promotion')) {

        originalPrice = parseFloat(req.body.original_price) || 0;
        discountPrice = parseFloat(req.body.discount_price) || 0;
        price = discountPrice;

    } else {
        price = parseFloat(req.body.price) || 0;
    }

    const imagePath = req.file
        ? '/uploads/' + req.file.filename
        : req.body.old_image;

    const data = {
        product_Code: req.body.product_Code,
        product_Name: req.body.product_Name,
        category,
        price,
        original_price: originalPrice,
        discount_price: discountPrice,
        type,
        stock: req.body.stock,
        description: req.body.description,
        image_path: imagePath
    };

    Product.updateProduct(productId, data, (err) => {

        if (err) {
            return next(new AppError(
                "Product update operation failed due to a system error.",
                400
            ));
        }

        Product.clearRoles(productId, () => {

            roles.forEach(roleName => {
                Product.addRoleToProduct(productId, roleName);
            });

            // 🔥 Redirect only admin
            res.redirect('/admin/products?success=updated');

        });

    });

};


/*
|--------------------------------------------------------------------------
| DELETE (Admin Only)
|--------------------------------------------------------------------------
*/

exports.deleteProduct = (req, res, next) => {

    Product.getProductById(req.params.id, (err, product) => {

        if (err) {
            return next(new AppError(
                "An error occurred while retrieving the requested product.",
                500
            ));
        }

        if (!product) {
            return next(new AppError(
                "The requested product could not be found in the system.",
                404
            ));
        }

        if (product.image_path) {

            const filePath = path.join(
                __dirname,
                '..',
                'public',
                product.image_path
            );

            if (fs.existsSync(filePath)) {
                fs.unlinkSync(filePath);
            }
        }

        Product.deleteProduct(req.params.id, (deleteErr) => {

            if (deleteErr) {
                return next(new AppError(
                    "Product deletion could not be completed due to a system error.",
                    500
                ));
            }

            // 🔥 Redirect only admin
            res.redirect('/admin/products?success=deleted');

        });

    });

};


/*
|--------------------------------------------------------------------------
| CATEGORY VIEW (Individual Items Only)
|--------------------------------------------------------------------------
*/

exports.showByCategory = (req, res, next) => {

    Product.getAllProducts((err, products) => {

        if (err) {
            return next(new AppError(
                "Unable to retrieve product records.",
                500
            ));
        }

        const onlyItems = products.filter(p => p.type === 'item');

        const grouped = {};

        onlyItems.forEach(product => {

            const category = product.category || "Uncategorized";

            if (!grouped[category]) {
                grouped[category] = [];
            }

            grouped[category].push(product);
        });

        res.render('products/categories', {
            grouped,
            user: req.session.user || null,
            currentPage: 'categories',
            theme: req.session.theme || 'theme-dark'
        });

    });

};


/*
|--------------------------------------------------------------------------
| PC SETS VIEW
|--------------------------------------------------------------------------
*/

exports.showPCSets = (req, res, next) => {

    Product.getAllProducts((err, products) => {

        if (err) {
            return next(new AppError(
                "Unable to retrieve PC set products.",
                500
            ));
        }

        const pcSets = products.filter(p => p.type === 'pc_set');

        res.render('products/pc', {
            products: pcSets,
            user: req.session.user || null,
            currentPage: 'pc',
            theme: req.session.theme || 'theme-dark'
        });

    });

};
exports.showBuildPage = (req, res, next) => {

    Product.getBuildCategories((err, categories) => {

        if (err) return next(err);

        res.render("products/build", {
            categories,
            theme: req.session.theme || 'theme-dark'
        });

    });

};

exports.createBuildOrder = async (req, res, next) => {

    try {

        const parts = req.body;

        
        const required = ["case", "mainboard", "cpu", "ram", "psu", "ssd"];

        const isValid = required.every(cat => parts[cat]);

        if (!isValid) {
            return res.status(400).json({
                error: "Missing required parts."
            });
        }

        let totalAmount = 0;

        
        for (const part of Object.values(parts)) {

            const product = await new Promise((resolve, reject) => {
                Product.getProductById(part.product_Id, (err, p) => {
                    if (err) reject(err);
                    else resolve(p);
                });
            });

            if (!product) {
                return res.status(400).json({
                    error: "Product not found."
                });
            }

            if (product.stock <= 0) {
                return res.status(400).json({
                    error: product.product_Name + " is out of stock."
                });
            }

            totalAmount += Number(product.discount_price || product.price);
        }

        
        const orderData = {
            order_Date: new Date().toISOString(),
            total_Amount: totalAmount,
            orderType: 'build',
            buildName: "Custom Build",
            customerId: req.session.user?.customerId || null
        };

        Order.createOrder(orderData, function (err) {

            if (err) {
                return next(new AppError("Failed to create build order.", 500));
            }

            const orderId = this.lastID;

         
            Object.values(parts).forEach(part => {

                OrderItem.createOrderItem({
                    orderId,
                    productId: part.product_Id,
                    quantity: 1,
                    unitPrice: part.price,
                    totalPrice: part.price
                });

            });

            return res.json({ orderId });

        });

    } catch (error) {

        return next(new AppError("Unexpected error during build checkout.", 500));

    }
};

exports.getBuildProducts = (req, res, next) => {

    const category = req.params.category;

    Product.getProductsByCategory(category, (err, products) => {

        if (err) return next(err);

        res.json(products);

    });

};
