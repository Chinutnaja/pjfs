const Payment = require('../models/payment.model');
const Order = require('../models/order.model');
const OrderItem = require('../models/orderItem.model');
const Product = require('../models/product.model');
const AppError = require('../utils/AppError');
const db = require('../database/db');
const path = require('path');

// ==========================
// PAY ORDER
// ==========================
exports.payOrder = (req, res, next) => {

    const { orderId, paymentMethod } = req.body;

    if (!orderId || !paymentMethod) {
        return next(new AppError(
            "Invalid payment request data.",
            400
        ));
    }

    Order.getOrderById(orderId, (err, order) => {

        if (err) {
            return next(new AppError(
                "Unable to retrieve order for payment.",
                500
            ));
        }

        if (!order) {
            return next(new AppError(
                "Order not found.",
                404
            ));
        }

        if (order.paymentStatus === 'paid') {
            return next(new AppError(
                "This order has already been paid.",
                400
            ));
        }

        // ==========================
        // ใช้ SQLite Transaction
        // ==========================
        db.serialize(() => {

            db.run("BEGIN TRANSACTION");

            OrderItem.getItemsByOrderId(orderId, (err2, items) => {

                if (err2) {
                    db.run("ROLLBACK");
                    return next(new AppError(
                        "Failed to retrieve order items.",
                        500
                    ));
                }

                try {

                    // 1️⃣ เช็ค stock ก่อนตัดจริง
                    items.forEach(item => {

                        Product.getProductById(item.productId, (err3, product) => {

                            if (err3 || !product || product.stock < item.quantity) {
                                db.run("ROLLBACK");
                                return next(new AppError(
                                    "Stock is insufficient for one or more products.",
                                    400
                                ));
                            }

                            const newStock = product.stock - item.quantity;

                            Product.updateStock(item.productId, newStock, () => {});
                        });
                    });

                    // 2️⃣ สร้าง Payment
                    const paymentData = {
                        orderId,
                        paymentDate: new Date().toISOString(),
                        amount: order.total_Amount,
                        paymentMethod,
                        transactionRef: "TXN-" + Date.now(),
                        paymentStatus: 'success'
                    };

                    Payment.createPayment(paymentData, (err4) => {

                        if (err4) {
                            db.run("ROLLBACK");
                            return next(new AppError(
                                "Payment processing failed.",
                                500
                            ));
                        }

                        // 3️⃣ update Order status
                        Order.updatePaymentStatus(orderId, 'paid', () => {

                            db.run("COMMIT");

                            return next(new AppError(
                                "Payment completed successfully.",
                                200
                            ));
                        });

                    });

                } catch (error) {
                    db.run("ROLLBACK");
                    return next(new AppError(
                        "Unexpected error occurred during payment.",
                        500
                    ));
                }

            });

        });

    });
};
exports.showPaymentPage = (req, res, next) => {

    const orderId = req.params.orderId;

    Order.getOrderById(orderId, (err, order) => {

        if (err || !order) {
            return next(new AppError("Order not found.", 404));
        }

        OrderItem.getItemsByOrderId(orderId, (err2, items) => {

            if (err2) {
                return next(new AppError("Failed to retrieve order items.", 500));
            }

            // ดึง product info เพิ่มเข้าไปแต่ละ item
            const promises = items.map(item => {
                return new Promise((resolve, reject) => {
                    Product.getProductById(item.productId, (err3, product) => {
                        if (err3 || !product) {
                            resolve(item);
                        } else {
                            resolve({
                                ...item,
                                product_Name: product.product_Name,
                                image_path: product.image_path
                            });
                        }
                    });
                });
            });

            Promise.all(promises).then(finalItems => {

                res.render('payments/payment', {
                    order,
                    items: finalItems,
                    user: req.session.user || null
                });

            });

        });

    });

};



exports.payWithSlip = (req, res, next) => {

    const { orderId } = req.body;

    if (!req.file) {
        return next(new AppError("Please upload a payment slip.", 400));
    }

    Order.getOrderById(orderId, (err, order) => {

        if (err || !order) {
            return next(new AppError("Order not found.", 404));
        }

        if (order.paymentStatus === 'paid') {
            return next(new AppError("This order has already been paid.", 400));
        }

        db.serialize(() => {

            db.run("BEGIN TRANSACTION");

            OrderItem.getItemsByOrderId(orderId, (err2, items) => {

                if (err2) {
                    db.run("ROLLBACK");
                    return next(new AppError("Failed to retrieve order items.", 500));
                }

                const processStock = async () => {
                    try {

                        for (const item of items) {

                            const product = await new Promise((resolve, reject) => {
                                Product.getProductById(item.productId, (e, p) => {
                                    if (e) reject(e);
                                    else resolve(p);
                                });
                            });

                            if (!product || product.stock < item.quantity) {
                                throw new Error("Stock is insufficient.");
                            }

                            const newStock = product.stock - item.quantity;

                            await new Promise((resolve, reject) => {
                                Product.updateStock(item.productId, newStock, (e) => {
                                    if (e) reject(e);
                                    else resolve();
                                });
                            });

                        }

                        const paymentData = {
                            orderId,
                            paymentDate: new Date().toISOString(),
                            amount: order.total_Amount,
                            paymentMethod: 'bank_transfer',
                            transactionRef: req.file.filename,
                            paymentStatus: 'success'
                        };

                        await new Promise((resolve, reject) => {
                            Payment.createPayment(paymentData, (e) => {
                                if (e) reject(e);
                                else resolve();
                            });
                        });

                        await new Promise((resolve, reject) => {
                            Order.updatePaymentStatus(orderId, 'paid', (e) => {
                                if (e) reject(e);
                                else resolve();
                            });
                        });

                        db.run("COMMIT");

                        return next(new AppError(
                            "Payment slip uploaded and stock updated successfully.",
                            200
                        ));

                    } catch (error) {
                        db.run("ROLLBACK");
                        return next(new AppError(error.message, 400));
                    }
                };

                processStock();

            });

        });

    });

};
