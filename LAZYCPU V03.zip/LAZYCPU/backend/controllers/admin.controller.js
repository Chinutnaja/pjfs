exports.dashboard = (req, res, next) => {

    const db = require('../database/db');

    const stats = {};

    // ================= TOTAL PAID ORDERS =================
    db.get(`
        SELECT COUNT(*) AS totalPaidOrders
        FROM Orders
        WHERE paymentStatus = 'paid'
    `, [], (err, row) => {

        if (err) return next(err);
        stats.totalPaidOrders = row.totalPaidOrders;

        // ================= TOTAL REVENUE =================
        db.get(`
            SELECT COALESCE(SUM(total_Amount),0) AS totalRevenue
            FROM Orders
            WHERE paymentStatus = 'paid'
        `, [], (err2, row2) => {

            if (err2) return next(err2);
            stats.totalRevenue = row2.totalRevenue;

            // ================= TOTAL CUSTOMERS =================
            db.get(`
                SELECT COUNT(*) AS totalCustomers
                FROM Customers
            `, [], (err3, row3) => {

                if (err3) return next(err3);
                stats.totalCustomers = row3.totalCustomers;

                res.render('admin/dashboard', {
                    stats,
                    theme: req.session.theme || 'theme-dark'
                });

            });

        });

    });

};


exports.adminCreateProduct = (req, res) => {

    res.render('products/create', {
        theme: req.session.theme || 'theme-dark',
        isAdmin: true
    });

};


exports.adminEditProduct = (req, res, next) => {

    Product.getProductById(req.params.id, (err, product) => {

        if (err) return next(err);

        res.render('products/edit', {
            product,
            theme: req.session.theme || 'theme-dark',
            isAdmin: true
        });

    });

};
const db = require('../database/db'); 

exports.adminCustomers = (req, res, next) => {

    const sql = `
        SELECT 
            customerId,
            firstname,
            lastname,
            email,
            username,
            phone,
            address,
            is_verified
        FROM Customers
        ORDER BY customerId DESC
    `;

    db.all(sql, [], (err, rows) => {

        if (err) {
            return next(err);
        }

        res.render('admin/customers', {
            customers: rows,
            theme: req.session.theme || 'theme-dark'
        });

    });
};
const Customer = require('../models/customer.model');
const Order = require('../models/order.model');
const AppError = require('../utils/AppError');
exports.deleteCustomer = (req, res, next) => {

    const id = req.params.id;

    // 🔒 ป้องกันลบ admin
    Customer.getCustomerById(id, (err, customer) => {

        if (err) {
            return next(new AppError("Unable to retrieve customer.", 500));
        }

        if (!customer) {
            return next(new AppError("Customer not found.", 404));
        }

        if (customer.role === 'admin') {
            return next(new AppError("Admin account cannot be deleted.", 400));
        }

        // 🔥 ถ้ามี order ห้ามลบ
        Order.getOrdersByCustomer(id, (err2, orders) => {

            if (err2) {
                return next(new AppError("Failed to validate customer orders.", 500));
            }

            if (orders.length > 0) {
                return next(new AppError(
                    "Customer cannot be deleted because order history exists.",
                    400
                ));
            }

            Customer.deleteCustomer(id, (err3) => {

                if (err3) {
                    return next(new AppError("Customer deletion failed.", 500));
                }

                res.redirect('/admin/customers?success=deleted');
            });

        });

    });

};
exports.adminOrders = (req, res, next) => {

    Order.getAllOrdersWithCustomer((err, orders) => {

        if (err) {
            return next(new AppError("Unable to retrieve orders.", 500));
        }

        res.render('admin/orders', {
            orders,
            theme: req.session.theme || 'theme-dark',
            success: req.query.success || null
        });

    });

};


exports.updateOrderStatus = (req, res, next) => {

    const { orderId, paymentStatus, shippingStatus } = req.body;

    Order.updateOrderStatus(orderId, paymentStatus, shippingStatus, (err) => {

        if (err) {
            return next(new AppError("Failed to update order status.", 500));
        }

        res.redirect('/admin/orders?success=updated');
    });

};
exports.approveSlip = (req, res, next) => {

    const { orderId } = req.body;

    const Order = require('../models/order.model');
    const OrderItem = require('../models/orderItem.model');
    const Product = require('../models/product.model');

    // 1️⃣ ดึงรายการสินค้าของ order
    OrderItem.getItemsByOrderId(orderId, (err, items) => {

        if (err) return next(err);

        // 2️⃣ ตัด stock ทีละตัว
        items.forEach(item => {

            Product.getProductById(item.productId, (err2, product) => {

                if (!err2 && product) {

                    // 🔥 ใส่ตรงนี้
                    if (product.stock >= item.quantity) {

                        const newStock = product.stock - item.quantity;

                        Product.updateStock(item.productId, newStock, () => {});

                    }

                }

            });

        });

        // 3️⃣ เปลี่ยนสถานะ order เป็น paid
        Order.updateOrderStatus(orderId, 'paid', 'preparing', (err3) => {

            if (err3) return next(err3);

            res.redirect('/admin/orders?success=approved');

        });

    });

};




exports.rejectSlip = (req, res, next) => {

    const { orderId } = req.body;

    Order.updateOrderStatus(orderId, 'failed', 'preparing', (err) => {

        if (err) {
            return next(new AppError("Failed to reject payment.", 500));
        }

        res.redirect('/admin/orders?success=rejected');
    });

};
exports.deleteOrder = (req, res, next) => {

    const orderId = req.params.id;

    Order.deleteOrderById(orderId, (err) => {

        if (err) {
            return next(new AppError("Failed to delete order.", 500));
        }

        res.redirect('/admin/orders?success=deleted');

    });

};