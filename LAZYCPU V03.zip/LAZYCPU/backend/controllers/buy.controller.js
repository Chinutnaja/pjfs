const Product = require('../models/product.model');
const Order = require('../models/order.model');
const OrderItem = require('../models/orderItem.model');
const AppError = require('../utils/AppError');

exports.buyNow = (req, res, next) => {

    if (!req.session.user) {
        return next(new AppError(
            "Please login before purchasing.",
            401
        ));
    }

    const productId = req.params.id;
    const quantity = parseInt(req.body.qty) || 1;
    const customerId = req.session.user.customerId;

    if (!productId) {
        return next(new AppError(
            "Invalid purchase request.",
            400
        ));
    }

    Product.getProductById(productId, (err, product) => {

        if (err) {
            return next(new AppError(
                "Unable to retrieve product information.",
                500
            ));
        }

        if (!product) {
            return next(new AppError(
                "Product not found.",
                404
            ));
        }

        if (quantity <= 0) {
            return next(new AppError(
                "Invalid quantity.",
                400
            ));
        }

        if (quantity > product.stock) {
            return next(new AppError(
                "Requested quantity exceeds available stock.",
                400
            ));
        }

        // ใช้ display_price ถ้ามี promotion
        const unitPrice = product.display_price || product.price;
        const totalAmount = unitPrice * quantity;

        Order.createOrder({
            order_Date: new Date().toISOString(),
            total_Amount: totalAmount,
            orderType: 'direct',   // 🔥 แยกจาก cart
            buildName: null,
            customerId
        }, (err2, orderId) => {

            if (err2) {
                return next(new AppError(
                    "Order creation failed due to a system error.",
                    500
                ));
            }

            OrderItem.createOrderItem({
                quantity: quantity,
                unitPrice: unitPrice,
                totalPrice: totalAmount,
                orderId: orderId,
                productId: productId
            }, (err3) => {

                if (err3) {
                    return next(new AppError(
                        "Failed to create order item.",
                        500
                    ));
                }

                return res.redirect(`/payments/${orderId}`);
            });

        });

    });
};
