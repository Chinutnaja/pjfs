const express = require('express');
const router = express.Router();
const controller = require('../controllers/product.controller');

const multer = require('multer');
const path = require('path');

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'public/uploads/');
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname));
    }
});

const upload = multer({ storage });

router.get('/products', controller.getAllProducts);
router.get('/products/create', controller.showCreateForm);
router.post('/products/create',
    upload.single('image'),
    controller.createProduct
);

router.get('/products/:id', controller.getProductDetail);
router.get('/products/edit/:id', controller.showEditForm);
router.post('/admin/products/edit/:id',
    upload.single('image'),
    controller.updateProduct
);

router.get('/products/delete/:id', controller.deleteProduct);
router.get('/categories', controller.showByCategory);
router.get('/pc', controller.showPCSets);
router.get('/build', controller.showBuildPage);
router.post('/build/checkout', controller.createBuildOrder);
router.get('/build/category/:category', controller.getBuildProducts);


module.exports = router;
